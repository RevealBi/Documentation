Reveal AI .NET SDK SBOM bundle
Package version: 1.5.213

This archive contains a CycloneDX JSON aggregate for the complete Reveal AI .NET SDK and one package-specific SBOM for each of the seven published NuGet packages.
Use the package-specific documents for the packages in your deployment, or the aggregate when you need the complete .NET AI distribution.
See manifest.json for file names, direct URLs, and SHA-256 hashes.
