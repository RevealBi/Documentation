Reveal Server .NET SDK SBOM bundle
Package version: 2.2.1

This archive contains CycloneDX JSON SBOMs for Reveal.Sdk.AspNetCore, every optional Reveal data connector NuGet package, and an aggregate document covering the base package plus all connectors.
Use the package-specific document for the packages in your deployment. The all-connectors aggregate is provided for customers who deploy every connector.
See manifest.json for file names, direct URLs, and SHA-256 hashes.
