Reveal Server Java SDK SBOM bundle
Package version: 2.2.1

This archive contains CycloneDX JSON SBOMs for the supported production deployment targets: Windows x64 and Linux x64.
Choose the document that matches your deployment architecture.
See manifest.json for file names, direct URLs, and SHA-256 hashes.
