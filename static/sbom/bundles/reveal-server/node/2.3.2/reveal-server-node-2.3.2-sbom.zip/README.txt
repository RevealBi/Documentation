Reveal 2.3.2 Node SBOMs

Draft: release-owner approval is pending. Each SBOM includes an embedded CycloneDX VEX assessment. Review vulnerabilities[].analysis and metadata.properties for assessment scope and limitations. Some findings remain exploitable or in_triage. These files do not certify an application deployment.
