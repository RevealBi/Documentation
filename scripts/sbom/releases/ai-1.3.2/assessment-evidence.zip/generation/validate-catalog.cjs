const fs = require('fs'), path = require('path'), crypto = require('crypto');
const [toolsDir, sbomRoot, manifestDir] = process.argv.slice(2);
const req = require('module').createRequire(path.join(toolsDir, 'package.json'));
const Ajv2020 = req('ajv/dist/2020'); const addFormats = req('ajv-formats');
const read = p => JSON.parse(fs.readFileSync(p, 'utf8'));
const sha = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const ajv = new Ajv2020({ strict: false, allErrors: true }); addFormats(ajv);
const catalog = read(path.join(sbomRoot, 'catalog.json'));
const vCat = ajv.compile(read(path.join(sbomRoot, 'catalog.schema.json')));
if (!vCat(catalog)) throw new Error('catalog: ' + JSON.stringify(vCat.errors));
console.log(`catalog.json valid against catalog.schema.json (${catalog.entries.length} entries)`);
let ok = 0;
for (const e of catalog.entries) { const f = path.join(sbomRoot, e.downloadUrl); const h = sha(f); if (h !== e.sha256) throw new Error(`hash mismatch ${e.id}: ${h}`); ok++; }
console.log(`catalog sha256 recomputed and matched for ${ok}/${catalog.entries.length} entries`);
const vMan = ajv.compile(read(path.join(sbomRoot, 'bundle-manifest.schema.json')));
let files = 0;
for (const m of fs.readdirSync(manifestDir)) {
  const man = read(path.join(manifestDir, m));
  if (!vMan(man)) throw new Error(m + ': ' + JSON.stringify(vMan.errors));
  files += man.files.length;
}
console.log(`${fs.readdirSync(manifestDir).length} bundle manifests valid against bundle-manifest.schema.json (${files} file records)`);
