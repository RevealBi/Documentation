// Map bundled .NET assemblies to NuGet package identities and prove identity by SHA-256 match
// against the same file inside the published .nupkg (local NuGet cache, else nuget.org download).
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto'; import { execFileSync } from 'node:child_process';
const [nativeDir, versionsTsv, outFile, dlDir] = process.argv.slice(2);
const sha = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const cache = path.join(process.env.USERPROFILE, '.nuget', 'packages');
const rows = fs.readFileSync(versionsTsv, 'utf8').trim().split(/\r?\n/).map(l => l.split('\t'));
const GENERIC = new Set(['AIPlugin', 'Reveal.Sdk.AI.Abstractions.Debug']);
const ID = { 'SqlParser': 'SqlParserCS', 'DotLiquid.resources': 'DotLiquid' };
function walk(d) { return fs.existsSync(d) ? fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]) : []; }
function pkgDir(id, version) {
  const local = path.join(cache, id.toLowerCase(), version.toLowerCase());
  if (fs.existsSync(local)) return { dir: local, source: 'local-nuget-cache' };
  const target = path.join(dlDir, id.toLowerCase(), version.toLowerCase());
  if (!fs.existsSync(target)) {
    fs.mkdirSync(target, { recursive: true });
    const nupkg = path.join(target, `${id.toLowerCase()}.${version.toLowerCase()}.nupkg`);
    execFileSync('curl', ['-sSfL', '-o', nupkg, `https://api.nuget.org/v3-flatcontainer/${id.toLowerCase()}/${version.toLowerCase()}/${id.toLowerCase()}.${version.toLowerCase()}.nupkg`]);
    execFileSync('unzip', ['-q', '-o', nupkg, '-d', target]);
  }
  return { dir: target, source: 'nuget.org' };
}
const out = {};
for (const [rel, fileVersion, productVersion] of rows) {
  const file = rel.split(path.win32.sep).join('/');
  const base = path.basename(file, '.dll');
  const full = path.join(nativeDir, file);
  const entry = { file: `native/${file}`, sha256: sha(full), fileVersion };
  if (GENERIC.has(base)) {
    Object.assign(entry, { ecosystem: 'generic', id: base, version: fileVersion });
  } else {
    const id = ID[base] ?? base;
    let version = productVersion.split('+')[0];
    if (id === 'DotLiquid') version = version.split('-')[0];
    if (id === 'SqlParserCS') version = version.replace(/-release\.0$/, '');
    const { dir, source } = pkgDir(id, version);
    const candidates = walk(dir).filter(p => path.basename(p).toLowerCase() === path.basename(file).toLowerCase());
    const match = candidates.find(p => sha(p) === entry.sha256);
    // First-party Reveal assemblies are a separate build of the same tagged commit; they are compared by decompilation instead.
    if (!match && !(id.startsWith('Reveal.Sdk.') && candidates.length === 1)) throw new Error(`No hash match for ${file} in ${id} ${version} (${candidates.length} candidates)`);
    const nuspec = walk(dir).find(p => p.toLowerCase().endsWith('.nuspec'));
    const packageFile = match ?? candidates[0];
    Object.assign(entry, { ecosystem: 'nuget', id, version, packageSource: source, packagePath: path.relative(dir, packageFile).split(path.win32.sep).join('/'), packageFileFullPath: packageFile, hashMatch: Boolean(match), nuspec });
  }
  out[file] = entry;
}
fs.writeFileSync(outFile, JSON.stringify(out, null, 2) + '\n');
for (const e of Object.values(out)) console.log(e.ecosystem, e.id, e.version, e.file, e.packageSource ?? '', e.packagePath ?? '', e.hashMatch === false ? 'HASH-DIFFERS' : '');
