// Validates CycloneDX documents against the official 1.7 schema and checks internal references.
// Usage: node validate.mjs <tools/validate dir> <schema dir> <file-or-dir>...
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const [toolsDir, schemaDir, ...targets] = process.argv.slice(2);
const require = createRequire(path.join(toolsDir, 'package.json'));
const Ajv = require('ajv');
const addFormats = require('ajv-formats');
const addDraft2019Formats = require('ajv-formats-draft2019');
const read = p => JSON.parse(fs.readFileSync(p, 'utf8'));

const ajv = new Ajv({ strict: false, allErrors: true });
addFormats(ajv);
addDraft2019Formats(ajv);
ajv.addSchema(read(path.join(schemaDir, 'cryptography-defs.schema.json')), 'http://cyclonedx.org/schema/cryptography-defs.schema.json');
ajv.addSchema(read(path.join(schemaDir, 'spdx.schema.json')), 'http://cyclonedx.org/schema/spdx.schema.json');
ajv.addSchema(read(path.join(schemaDir, 'jsf-0.82.schema.json')), 'http://cyclonedx.org/schema/jsf-0.82.schema.json');
const validate = ajv.compile(read(path.join(schemaDir, 'bom-1.7.schema.json')));

const files = targets.flatMap(function walk(target) {
  const stat = fs.statSync(target);
  if (stat.isFile()) return [target];
  return fs.readdirSync(target).flatMap(name => walk(path.join(target, name))).filter(file => file.endsWith('.cdx.json'));
});

for (const file of files) {
  const doc = read(file);
  if (!validate(doc)) throw new Error(`${file}: ${JSON.stringify(validate.errors, null, 2)}`);
  if (doc.specVersion !== '1.7') throw new Error(`${file}: specVersion ${doc.specVersion}`);
  const all = [doc.metadata.component, ...doc.components];
  const refs = new Set(all.map(c => c['bom-ref']));
  if (refs.size !== all.length) throw new Error(`${file}: duplicate bom-ref`);
  for (const d of doc.dependencies ?? []) for (const r of [d.ref, ...(d.dependsOn ?? [])]) if (!refs.has(r)) throw new Error(`${file}: unknown dependency ${r}`);
  for (const v of doc.vulnerabilities ?? []) for (const a of v.affects ?? []) if (!refs.has(a.ref)) throw new Error(`${file}: unknown VEX component ${a.ref}`);
  const names = (doc.metadata.properties ?? []).map(p => p.name);
  for (const required of ['io.revealbi.sbom.release', 'io.revealbi.sbom.inventory-scope', 'reveal:vex:assessment-date', 'reveal:vex:statement-count']) {
    if (!names.includes(required)) throw new Error(`${file}: missing metadata property ${required}`);
  }
  if (names.includes('io.revealbi.sbom.publication-status')) throw new Error(`${file}: unexpected publication-status property`);
  const count = doc.vulnerabilities?.length ?? 0;
  if (String(count) !== doc.metadata.properties.find(p => p.name === 'reveal:vex:statement-count').value) throw new Error(`${file}: statement-count mismatch`);
  console.log(`OK ${path.basename(file)}: ${doc.components.length} components, ${doc.dependencies.length} dependency entries, ${count} VEX statements`);
}
console.log(`Validated ${files.length} CycloneDX 1.7 documents against the official schema, plus dependency and VEX references.`);
