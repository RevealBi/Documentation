# Reveal AI 1.3.2 SBOM/VEX: commands used

`${WORKDIR}` is the empty working directory created for this assessment. Downloaded content was kept under `dl/` and never executed; scripts live under `scripts/`.

## Tools

- Apache Maven 3.9.16 (`apache-maven-3.9.16-bin.zip`, verified against the Apache `.sha512`)
- syft 1.57.2 (`syft_1.57.2_windows_amd64.zip`, verified against `syft_1.57.2_checksums.txt`)
- OSV-Scanner 2.7.1 (`osv-scanner_windows_amd64.exe`, verified against `osv-scanner_SHA256SUMS`)
- org.cyclonedx:cyclonedx-maven-plugin 2.9.3, resolved from Maven Central
- Node v22.14.0, npm 11.4.2, javap 21.0.12.1, ilspycmd 9.1.0.7988, ajv 8.17.1

## Java

```text
curl https://maven.revealbi.io/repository/public/io/revealbi/reveal-sdk-ai/1.3.2/reveal-sdk-ai-1.3.2.{jar,pom}  (+ .sha1, verified)
mvn -B -C -s projects/java/settings.xml -f projects/java/pom.xml -Dmaven.repo.local=work/java/m2 \
    dependency:3.8.1:tree -Dscope=runtime                      # dependency-tree-host-activated.txt
mvn -B -C -s projects/java/settings.xml -f projects/java/pom.xml -Dmaven.repo.local=work/java/m2 \
    org.cyclonedx:cyclonedx-maven-plugin:2.9.3:makeBom -DincludeTestScope=false -DincludeProvidedScope=false \
    -DoutputFormat=json -DoutputName=maven \
    dependency:3.8.1:copy-dependencies -DincludeScope=runtime
syft scan dir:dl/java/jar -o syft-json -o cyclonedx-json@1.7      # dl/java/jar = extracted JAR
```

The wrapper POM excludes `io.revealbi:reveal-sdk-engine-windows-x86_64`, the engine that reveal-sdk-core 2.3.0 selects through an OS-activated profile on the generation host. `-P!<profile>` does not deactivate profiles in dependency POMs in Maven 3.9.16, so an explicit exclusion was used.

## Node

```text
npm view reveal-sdk-node-ai@1.3.2 dist.integrity dist.shasum dist.tarball dependencies
npm pack reveal-sdk-node-ai@1.3.2 --ignore-scripts                 (SHA-512/SHA-1 verified against the registry)
npm install --ignore-scripts --omit=dev --no-audit --no-fund       (projects/node/package.json)
syft scan dir:dl/node/install -o cyclonedx-json@1.7 -o syft-json
```

All npm commands used an empty `--userconfig`, a private `--cache` and `--registry https://registry.npmjs.org/`.

## Assembly, scan, VEX

```text
node scripts/map-native.mjs dl/java/jar/native work/native-versions.tsv work/native-map.json dl/nuget
node scripts/assemble.mjs ${WORKDIR} staging/files
OSV_SCANNER_LOCAL_DB_CACHE_DIRECTORY=tools/osv-db osv-scanner scan source \
    --offline --no-resolve --no-ignore --all-packages --format json --output-file work/scan/osv-results.json -r files
node <repo>/scripts/sbom/apply-vex.mjs --scan work/scan/osv-results.json \
    --assessments <repo>/scripts/sbom/releases/ai-1.3.2/vex-assessments.json --sbom-root staging/files
node scripts/validate.mjs tools/validate tools/validate/schema-1.7.2 staging/files
```

`tools/osv-db/osv-scalibr/{Maven,NuGet,npm}/all.zip` were downloaded from `https://osv-vulnerabilities.storage.googleapis.com/<ecosystem>/all.zip` on 2026-11-26 and verified against the storage MD5 header.

## Static review

```text
javap -c -p -v -cp <jar> <every class>     # reveal-sdk-ai 1.3.2, reveal-sdk-servlet 2.3.0, reveal-sdk-core 2.3.0
javap -c -p -cp <jar> <every class>        # jackson-core 2.17.2, jackson-databind 2.17.2
javap -c -p -cp reveal-sdk-core-2.3.2.jar io.revealbi.core.impl.CallbackServer
javap -c -p -cp jetty-server-12.0.12.jar org.eclipse.jetty.server.ServerConnector
ilspycmd <assembly> -r dl/java/jar/native  # bundled vs NuGet Reveal.Sdk.AI* assemblies, compared by diff
```

## Catalog

`scripts/sbom/rebuild-bundles.ps1 -RepositoryRoot <scratch copy>` computed the two new catalog hashes. Running it in place re-zips every existing bundle and changes their bytes and catalog hashes without content changes, so only the two new `file` entries were applied to the repository catalog. `validate-catalog.cjs` then validated the catalog and every bundle manifest against the repository schemas and recomputed all stored SHA-256 values.

## Site

```text
npm run build
npx docusaurus serve --port 3217 --no-open
node scripts/check-page.mjs <msedge.exe> <empty profile dir> http://localhost:3217/trust/sbom/
```

`check-page.mjs` drives headless Edge over the DevTools protocol, reads the rendered SBOM table and fetches both new downloads in the page to compare their SHA-256 with the catalog.
