// Assembles the Reveal AI 1.3.2 Java and Node CycloneDX 1.7 SBOMs from generator output.
// Inputs are generator results and downloaded package metadata; nothing from the downloads is executed.
// Usage: node assemble.mjs <scratch-root> <output-files-root>
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const [root, outRoot] = process.argv.slice(2);
const p = (...parts) => path.join(root, ...parts);
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const write = (file, value) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`); };
const digest = (alg, file) => crypto.createHash(alg).update(fs.readFileSync(file)).digest('hex');
const sriToHex = sri => Buffer.from(sri.slice(sri.indexOf('-') + 1), 'base64').toString('hex');
const prop = (name, value) => ({ name, value });

const VERSION = '1.3.2';
const RELEASE = 'ai-1.3.2';
const DATE = '2026-11-26T14:44:00Z';
const NATIVE_TAG = 'v1.7.21-preview';
const NATIVE_COMMIT = '5ada28193ec979abc8a3c08c06a2e891af7f1983';
const RELEASE_COMMIT = '7f5636e2c30bbfc616c2209b33c9b5d0ec36417b';
const WEBSITE = 'https://help.revealbi.io/ai/install-server-sdk/';
// The Reveal.Sdk.AI nuspecs point at a private source repository; such links are not published.
const PRIVATE_URL = /github\.com\/[^/]+\/Reveal\.Sdk\.AI(\.git)?$/i;
const SUPPLIER = { name: 'Infragistics' };
const syftTool = { type: 'application', author: 'anchore', name: 'syft', version: '1.57.2' };

// ---------- embedded .NET assemblies (shared by both packages; byte-identical in JAR and tarball) ----------
function nuspecMetadata(file) {
  if (!file) return {};
  const xml = fs.readFileSync(file, 'utf8');
  const tag = name => xml.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`))?.[1]?.trim();
  const decode = s => s?.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
  const result = {};
  const authors = decode(tag('authors'));
  if (authors) result.authors = [{ name: authors }];
  const description = decode(tag('description'));
  if (description) result.description = description;
  const licenseExpression = xml.match(/<license\s+type="expression">([^<]+)<\/license>/)?.[1]?.trim();
  if (licenseExpression) {
    result.licenses = /\s(OR|AND|WITH)\s/.test(licenseExpression)
      ? [{ expression: licenseExpression }]
      : [{ license: { id: licenseExpression } }];
  }
  const copyright = decode(tag('copyright'));
  if (copyright) result.copyright = copyright;
  const references = [];
  const projectUrl = decode(tag('projectUrl'));
  if (projectUrl && !PRIVATE_URL.test(projectUrl)) references.push({ url: projectUrl, type: 'website' });
  const repository = xml.match(/<repository\s[^>]*url="([^"]+)"/)?.[1];
  if (repository && !PRIVATE_URL.test(repository)) references.push({ url: repository.replace(/^git\+/, ''), type: 'vcs' });
  if (references.length > 0) result.externalReferences = references;
  return result;
}

function nativeComponents() {
  const map = read(p('work', 'native-map.json'));
  const groups = new Map();
  for (const entry of Object.values(map)) {
    const key = `${entry.ecosystem}|${entry.id}|${entry.version}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(entry);
  }
  const components = [];
  for (const entries of groups.values()) {
    entries.sort((a, b) => a.file.localeCompare(b.file));
    const first = entries[0];
    const purl = `pkg:${first.ecosystem}/${first.id}@${first.version}`;
    const properties = [
      prop('infragistics:bundled-binary', 'true'),
      prop('infragistics:binary-file-version', first.fileVersion),
    ];
    for (const entry of entries) {
      properties.push(prop('infragistics:bundled-path', entry.file));
      properties.push(prop('infragistics:bundled-file-sha256', `${entry.file}=${entry.sha256}`));
    }
    if (first.ecosystem === 'nuget') {
      if (entries.every(entry => entry.hashMatch)) {
        properties.push(prop('infragistics:nuget-binary-match', 'true'));
      } else {
        properties.push(prop('infragistics:nuget-binary-match', 'false'));
        properties.push(prop('infragistics:build-variant',
          `Plugin build variant compiled from the same source commit (${NATIVE_COMMIT.slice(0, 10)}) and version as the NuGet package, Release configuration. Separate build; not byte-identical to the NuGet package file.`));
      }
    }
    const component = {
      type: 'library',
      'bom-ref': purl,
      ...(first.ecosystem === 'generic' ? { supplier: SUPPLIER } : {}),
      name: first.id,
      version: first.version,
      scope: 'required',
      purl,
      ...nuspecMetadata(first.nuspec),
      properties,
    };
    // Keep CycloneDX key order readable: identity first, then metadata, then properties.
    const { properties: props, ...rest } = component;
    components.push({ ...rest, properties: props });
  }
  return components.sort((a, b) => a.purl.localeCompare(b.purl));
}

function baseDocument(component, tools, properties) {
  return {
    $schema: 'https://cyclonedx.org/schema/bom-1.7.schema.json',
    bomFormat: 'CycloneDX',
    specVersion: '1.7',
    serialNumber: `urn:uuid:${crypto.randomUUID()}`,
    version: 1,
    metadata: {
      timestamp: DATE,
      lifecycles: [{ phase: 'post-build' }],
      tools: { components: tools },
      component,
      manufacturer: { name: 'Infragistics, Inc.' },
      properties,
    },
    components: [],
    dependencies: [],
  };
}

function checkReferences(doc, label) {
  const all = [doc.metadata.component, ...doc.components];
  const refs = new Set(all.map(c => c['bom-ref']));
  if (refs.size !== all.length) throw new Error(`Duplicate bom-ref in ${label}`);
  for (const d of doc.dependencies) for (const r of [d.ref, ...(d.dependsOn ?? [])]) if (!refs.has(r)) throw new Error(`Dangling reference in ${label}: ${r}`);
  const withEntry = new Set(doc.dependencies.map(d => d.ref));
  for (const r of refs) if (!withEntry.has(r)) throw new Error(`Component without dependency entry in ${label}: ${r}`);
}

const natives = nativeComponents();

// ---------- Java ----------
{
  const maven = read(p('work', 'java', 'raw', 'maven.json'));
  const wrapperRef = maven.metadata.component['bom-ref'];
  const jarPath = p('dl', 'java', 'reveal-sdk-ai-1.3.2.jar');
  const pluginTool = maven.metadata.tools.components.find(t => t.name === 'cyclonedx-maven-plugin');
  const mainRef = 'pkg:maven/io.revealbi/reveal-sdk-ai@1.3.2?type=jar';
  const mavenMain = maven.components.find(c => c['bom-ref'] === mainRef);
  if (!mavenMain) throw new Error('Maven output does not contain reveal-sdk-ai 1.3.2');
  if (maven.components.some(c => c.name.startsWith('reveal-sdk-engine-'))) throw new Error('Engine was not excluded');
  if (mavenMain.hashes.find(h => h.alg === 'SHA-256').content !== digest('sha256', jarPath)) throw new Error('JAR hash mismatch');

  const main = {
    type: 'library',
    'bom-ref': mainRef,
    supplier: SUPPLIER,
    group: 'io.revealbi',
    name: 'reveal-sdk-ai',
    version: VERSION,
    description: 'Reveal SDK AI plugin for Java — adds AI capabilities to Reveal BI dashboards',
    licenses: [{ license: { name: 'Reveal License' } }],
    purl: mainRef,
    hashes: mavenMain.hashes,
    externalReferences: [
      { type: 'distribution', url: 'https://maven.revealbi.io/repository/public/io/revealbi/reveal-sdk-ai/1.3.2/reveal-sdk-ai-1.3.2.jar' },
      { type: 'website', url: WEBSITE },
    ],
    properties: [
      prop('infragistics:release-tag', NATIVE_TAG),
      prop('infragistics:native-source-commit', NATIVE_COMMIT),
      prop('infragistics:source-commit', RELEASE_COMMIT),
      prop('infragistics:scope', 'AI wrapper plus the reveal-sdk-servlet 2.3.0 Maven runtime graph declared by its POM. The OS-selected reveal-sdk-engine 2.3.0 dependency is not inventoried here.'),
    ],
  };

  const doc = baseDocument(main, [pluginTool, syftTool], [
    prop('maven.goal', 'makeBom'),
    prop('maven.scopes', 'compile,runtime,system'),
    prop('io.revealbi.sbom.platform-resolution', 'Platform independent. reveal-sdk-core 2.3.0 selects reveal-sdk-engine-<os>-<arch> 2.3.0 through OS-activated Maven profiles; that host-selected engine dependency was excluded during resolution and is not part of this inventory.'),
    prop('io.revealbi.sbom.release', RELEASE),
    prop('io.revealbi.sbom.inventory-scope', 'Published Maven compile/runtime dependencies of io.revealbi:reveal-sdk-ai:1.3.2 resolved from its released POM in isolation (Maven 3.9.16): reveal-sdk-servlet 2.3.0, reveal-sdk-core 2.3.0, Jetty 12.0.12, org.json, SLF4J API and Jackson 2.17.2 (the AI POM pins jackson-databind 2.17.2, which overrides the core [2.13,3.0) range). Plus the .NET assemblies bundled under native/ in the JAR, identified as NuGet packages. Excluded: the OS-selected reveal-sdk-engine 2.3.0 JAR, host-provided assemblies the plugin loads from the Reveal engine, provided servlet API, and host operating-system libraries. An application that declares a newer Reveal Java SDK overrides the 2.3.0 graph.'),
  ]);

  for (const component of maven.components) {
    if (component['bom-ref'] === mainRef) continue;
    const copy = { ...component };
    if (copy.group === 'io.revealbi') copy.supplier = SUPPLIER;
    doc.components.push(copy);
  }
  doc.components.push(...natives);

  for (const dependency of maven.dependencies) {
    if (dependency.ref === wrapperRef) continue;
    doc.dependencies.push({ ref: dependency.ref, dependsOn: [...(dependency.dependsOn ?? [])] });
  }
  const mainDependency = doc.dependencies.find(d => d.ref === mainRef);
  mainDependency.dependsOn.push(...natives.map(c => c['bom-ref']));
  for (const component of natives) doc.dependencies.push({ ref: component['bom-ref'], dependsOn: [] });

  checkReferences(doc, 'java');
  write(path.join(outRoot, 'reveal-ai', 'java', VERSION, `reveal-sdk-ai-java-${VERSION}.cdx.json`), doc);
  console.log(`java: ${doc.components.length} components, ${doc.dependencies.length} dependency entries`);
}

// ---------- Node ----------
{
  const tgzPath = p('dl', 'node', 'pack', 'reveal-sdk-node-ai-1.3.2.tgz');
  const view = read(p('work', 'node', 'reveal-sdk-node-ai-1.3.2-view.json'));
  const integrity = view['dist.integrity'];
  if (`sha512-${crypto.createHash('sha512').update(fs.readFileSync(tgzPath)).digest('base64')}` !== integrity) throw new Error('npm integrity mismatch');
  if (digest('sha1', tgzPath) !== view['dist.shasum']) throw new Error('npm shasum mismatch');

  const lock = read(p('dl', 'node', 'install', 'package-lock.json'));
  const syft = read(p('work', 'node', 'raw', 'syft.cdx.json'));
  const syftNpm = new Map(syft.components.filter(c => c.purl?.startsWith('pkg:npm/')).map(c => [c.purl, c]));
  const purlOf = (name, version) => `pkg:npm/${name.startsWith('@') ? `%40${name.slice(1)}` : name}@${version}`;
  const nameOf = key => key.slice(key.lastIndexOf('node_modules/') + 'node_modules/'.length);

  const mainRef = purlOf('reveal-sdk-node-ai', VERSION);
  const main = {
    type: 'library',
    'bom-ref': mainRef,
    supplier: SUPPLIER,
    name: 'reveal-sdk-node-ai',
    version: VERSION,
    description: 'Reveal SDK AI plugin for Node.js — adds AI capabilities to Reveal BI dashboards',
    hashes: [
      { alg: 'SHA-1', content: view['dist.shasum'] },
      { alg: 'SHA-256', content: digest('sha256', tgzPath) },
      { alg: 'SHA-512', content: sriToHex(integrity) },
    ],
    licenses: [{ license: { name: 'Reveal License' } }],
    purl: mainRef,
    externalReferences: [
      { type: 'distribution', url: view['dist.tarball'] },
      { type: 'website', url: WEBSITE },
    ],
    properties: [
      prop('infragistics:release-tag', NATIVE_TAG),
      prop('infragistics:native-source-commit', NATIVE_COMMIT),
      prop('infragistics:source-commit', RELEASE_COMMIT),
      prop('infragistics:npm-integrity', integrity),
      prop('infragistics:scope', 'AI wrapper plus the npm production graph of reveal-sdk-node resolved from the declared range >=2.3.0. The engine that reveal-sdk-node downloads in its install script is not inventoried here.'),
    ],
  };

  const doc = baseDocument(main, [syftTool], [
    prop('io.revealbi.sbom.platform-resolution', 'Platform independent. The package contains no OS- or architecture-specific binaries; the platform engine is downloaded by the reveal-sdk-node install script, which was not run.'),
    prop('io.revealbi.sbom.release', RELEASE),
    prop('io.revealbi.sbom.inventory-scope', 'npm production dependencies of reveal-sdk-node-ai@1.3.2 from a clean install on 2026-11-26 (npm 11.4.2, --omit=dev, --ignore-scripts; dependency edges from package-lock.json). The declared range reveal-sdk-node >=2.3.0 resolved to 2.3.2; a later install can select different versions. Plus the .NET assemblies bundled under native/, identified as NuGet packages. Excluded: the engine downloaded by the reveal-sdk-node install script, host-provided assemblies the plugin loads from the Reveal engine, and host operating-system libraries.'),
  ]);

  const packages = lock.packages;
  const keyToRef = new Map();
  for (const [key, entry] of Object.entries(packages)) {
    if (!key) continue;
    const name = entry.name ?? nameOf(key);
    if (name === 'reveal-sdk-node-ai') { keyToRef.set(key, mainRef); continue; }
    const purl = purlOf(name, entry.version);
    keyToRef.set(key, purl);
    if (doc.components.some(c => c['bom-ref'] === purl)) continue;
    const fromSyft = syftNpm.get(purl);
    if (!fromSyft) throw new Error(`syft did not catalog ${purl}`);
    const component = {
      type: 'library',
      'bom-ref': purl,
      ...(name === 'reveal-sdk-node' ? { supplier: SUPPLIER } : {}),
      name,
      version: entry.version,
      scope: entry.optional ? 'optional' : 'required',
      ...(entry.integrity?.startsWith('sha512-') ? { hashes: [{ alg: 'SHA-512', content: sriToHex(entry.integrity) }] } : {}),
      ...(fromSyft.licenses ? { licenses: fromSyft.licenses } : {}),
      ...(fromSyft.cpe ? { cpe: fromSyft.cpe } : {}),
      purl,
      ...(entry.resolved ? { externalReferences: [{ type: 'distribution', url: entry.resolved }] } : {}),
    };
    if (name === 'reveal-sdk-node') {
      component.properties = [
        prop('infragistics:declared-version-range', '>=2.3.0'),
        prop('infragistics:install-script', 'Downloads the platform engine at install time; not run during this assessment.'),
        prop('infragistics:required-platform-sbom', 'Reveal Server SDK Node 2.3.2 SBOM (win-x64 or linux-x64) for the engine'),
      ];
    }
    doc.components.push(component);
  }

  function resolveKey(from, name) {
    let base = from;
    for (;;) {
      const candidate = `${base ? `${base}/` : ''}node_modules/${name}`;
      if (packages[candidate]) return candidate;
      if (!base) return null;
      const index = base.lastIndexOf('/node_modules/');
      base = index < 0 ? '' : base.slice(0, index);
    }
  }
  const edges = new Map();
  for (const [key, entry] of Object.entries(packages)) {
    if (!key) continue;
    const ref = keyToRef.get(key);
    if (!edges.has(ref)) edges.set(ref, new Set());
    const declared = { ...(entry.dependencies ?? {}), ...(entry.optionalDependencies ?? {}), ...(entry.peerDependencies ?? {}) };
    for (const name of Object.keys(declared)) {
      const target = resolveKey(key, name);
      if (target) edges.get(ref).add(keyToRef.get(target));
    }
  }
  doc.components.push(...natives);
  for (const component of natives) edges.get(mainRef).add(component['bom-ref']);
  for (const component of natives) edges.set(component['bom-ref'], new Set());
  doc.dependencies = [...edges.entries()].map(([ref, set]) => ({ ref, dependsOn: [...set].sort() }));
  doc.components.sort((a, b) => a.purl.localeCompare(b.purl));

  checkReferences(doc, 'node');
  write(path.join(outRoot, 'reveal-ai', 'node', VERSION, `reveal-sdk-ai-node-${VERSION}.cdx.json`), doc);
  console.log(`node: ${doc.components.length} components, ${doc.dependencies.length} dependency entries`);
}
