// Loads the SBOM page in headless Edge over the DevTools protocol and reports what the page rendered.
// Usage: node check-page.mjs <edge.exe> <profile-dir> <url>
import { spawn } from 'node:child_process';

const [edge, profile, url] = process.argv.slice(2);
const port = 9347;
const browser = spawn(edge, ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
  `--user-data-dir=${profile}`, `--remote-debugging-port=${port}`, 'about:blank'], { stdio: 'ignore' });
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

try {
  let targets;
  for (let i = 0; i < 50 && !targets; i++) {
    try { targets = await (await fetch(`http://127.0.0.1:${port}/json`)).json(); } catch { await sleep(200); }
  }
  const page = targets.find(t => t.type === 'page');
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise(resolve => ws.addEventListener('open', resolve, { once: true }));
  let id = 0;
  const pending = new Map();
  const consoleErrors = [];
  ws.addEventListener('message', event => {
    const msg = JSON.parse(event.data);
    if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
    if (msg.method === 'Runtime.exceptionThrown') consoleErrors.push(msg.params.exceptionDetails.text);
    if (msg.method === 'Runtime.consoleAPICalled' && msg.params.type === 'error') consoleErrors.push(msg.params.args.map(a => a.value ?? a.description).join(' '));
  });
  const send = (method, params = {}) => new Promise(resolve => { const n = ++id; pending.set(n, resolve); ws.send(JSON.stringify({ id: n, method, params })); });
  await send('Runtime.enable');
  await send('Page.enable');
  await send('Page.navigate', { url });
  const evaluate = async expression => (await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true })).result.result.value;
  let state;
  for (let i = 0; i < 60; i++) {
    await sleep(500);
    state = await evaluate(`(() => {
      const links = [...document.querySelectorAll('a[href*="/sbom/"]')].map(a => a.getAttribute('href'));
      return { title: document.title, links, text: document.body.innerText };
    })()`);
    if (state?.links?.some(l => l.includes('reveal-ai/java/1.3.2'))) break;
  }
  const aiLinks = state.links.filter(l => l.includes('reveal-ai'));
  const downloads = [];
  for (const href of aiLinks.filter(l => l.includes('1.3.2'))) {
    const result = await evaluate(`fetch(${JSON.stringify(href)}).then(async r => {
      const buf = await r.arrayBuffer();
      const digest = await crypto.subtle.digest('SHA-256', buf);
      return { href: ${JSON.stringify(href)}, status: r.status, bytes: buf.byteLength,
        sha256: [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, '0')).join('') };
    })`);
    downloads.push(result);
  }
  const lines = state.text.split('\n').map(s => s.trim()).filter(Boolean);
  const aiRows = lines.filter(l => /Reveal AI|1\.3\.2|1\.2\.0|Platform independent/.test(l)).slice(0, 30);
  console.log(JSON.stringify({ title: state.title, totalSbomLinks: state.links.length, aiLinks, downloads,
    errorTextOnPage: /could not|failed to load|error/i.test(state.text), consoleErrors, aiRows }, null, 2));
  ws.close();
} finally {
  browser.kill();
}
