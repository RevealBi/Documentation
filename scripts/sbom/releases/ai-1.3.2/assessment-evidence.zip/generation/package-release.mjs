// Builds the ai-1.3.2 release records (provenance.json, scan-summary.json) and stages the evidence and
// combined archives. Local absolute paths are replaced with ${WORKDIR}; nothing from downloads is executed.
// Usage: node package-release.mjs <scratch-root> <repo-release-dir>
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';

const [root, releaseDir] = process.argv.slice(2);
const p = (...parts) => path.join(root, ...parts);
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const write = (file, value) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, typeof value === 'string' ? value : `${JSON.stringify(value, null, 2)}\n`); };
const copy = (from, to) => { fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(from, to); };
const rootPosix = root.replaceAll('\\', '/');
const sanitize = text => text.split(root).join('${WORKDIR}').split(rootPosix).join('${WORKDIR}')
  .split(root.replaceAll('\\', '\\\\')).join('${WORKDIR}')
  .replace(/C:\\\\Users\\\\[^\\]+\\\\\.nuget\\\\packages/gi, '${NUGET_PACKAGES}')
  .replace(/C:\\Users\\[^\\]+\\\.nuget\\packages/gi, '${NUGET_PACKAGES}');

const DATE = read(path.join(releaseDir, 'vex-assessments.json')).assessment.date;
const evidenceRoot = p('release', 'evidence');
const combinedRoot = p('release', 'combined');
fs.rmSync(p('release'), { recursive: true, force: true });

// ---------- scan results with portable paths ----------
const scanText = fs.readFileSync(p('work', 'scan', 'osv-results.json'), 'utf8');
const scan = JSON.parse(scanText);
for (const result of scan.results) {
  const normalized = result.source.path.replaceAll('\\', '/');
  result.source.path = normalized.slice(normalized.indexOf('/files/') + 1);
}
const portableScan = `${JSON.stringify(scan, null, 2)}\n`;
write(path.join(evidenceRoot, 'osv-results.json'), portableScan);
write(path.join(combinedRoot, 'osv-results.json'), portableScan);
write(path.join(evidenceRoot, 'osv-scan.log'), sanitize(fs.readFileSync(p('work', 'scan', 'osv-scan.log'), 'utf8')));

// ---------- scan summary ----------
const assessments = read(path.join(releaseDir, 'vex-assessments.json'));
const states = Object.fromEntries(['not_affected', 'exploitable', 'in_triage'].map(state => [state, assessments.decisions.filter(d => d.analysis.state === state).length]));
const documents = scan.results.map(result => {
  const file = result.source.path.replace(/^files\//, '');
  const doc = read(p('staging', 'files', ...file.split('/')));
  return {
    file,
    components: doc.components.length,
    matchedPackages: result.packages?.length ?? 0,
    statements: (result.packages ?? []).reduce((n, pkg) => n + (pkg.vulnerabilities?.length ?? 0), 0),
  };
});
const databases = ['NuGet', 'npm', 'Maven'].map(ecosystem => {
  const dir = p('tools', 'osv-db', 'osv-scalibr', ecosystem);
  const lastModified = fs.readFileSync(path.join(dir, 'headers.txt'), 'utf8').match(/^last-modified:\s*(.+)$/im)?.[1]?.trim();
  return { ecosystem, url: `https://osv-vulnerabilities.storage.googleapis.com/${ecosystem}/all.zip`, sha256: sha(path.join(dir, 'all.zip')), lastModified: new Date(lastModified).toISOString() };
});
const scanSummary = { date: DATE, documents, decisions: assessments.decisions.length, states, databases };
write(path.join(releaseDir, 'scan-summary.json'), scanSummary);
write(path.join(evidenceRoot, 'evidence', 'scan-coverage.json'), scanSummary);

// ---------- provenance ----------
const artifact = (label, file) => ({ file: label, bytes: fs.statSync(file).size, sha256: sha(file) });
const artifacts = [
  artifact('artifacts/reveal-sdk-ai-1.3.2.jar', p('dl', 'java', 'reveal-sdk-ai-1.3.2.jar')),
  artifact('artifacts/reveal-sdk-ai-1.3.2.pom', p('dl', 'java', 'reveal-sdk-ai-1.3.2.pom')),
  artifact('artifacts/reveal-sdk-node-ai-1.3.2.tgz', p('dl', 'node', 'pack', 'reveal-sdk-node-ai-1.3.2.tgz')),
  ...['reveal-sdk-servlet-2.3.0.pom', 'reveal-sdk-core-2.3.0.pom', 'reveal-sdk-root-2.3.0.pom'].map(f => artifact(`maven/${f}`, p('dl', 'java', f))),
  ...fs.readdirSync(p('dl', 'java', 'deps')).filter(f => f.endsWith('.jar') && f !== 'reveal-sdk-ai-1.3.2.jar').sort().map(f => artifact(`maven/${f}`, p('dl', 'java', 'deps', f))),
  artifact('npm/reveal-sdk-node-2.3.2.tgz', p('dl', 'node', 'ref', 'reveal-sdk-node-2.3.2.tgz')),
  artifact('reference/reveal-sdk-core-2.3.2.jar', p('dl', 'java', 'ref232', 'reveal-sdk-core-2.3.2.jar')),
];
const nativeMap = read(p('work', 'native-map.json'));
const nugetPackages = new Map();
for (const entry of Object.values(nativeMap)) {
  if (entry.ecosystem !== 'nuget') continue;
  const key = `${entry.id}@${entry.version}`;
  if (nugetPackages.has(key)) continue;
  const dir = path.dirname(entry.nuspec);
  const nupkg = fs.readdirSync(dir).find(f => f.endsWith('.nupkg'));
  nugetPackages.set(key, { ...artifact(`nuget/${nupkg}`, path.join(dir, nupkg)), source: entry.packageSource });
}
const toolHash = file => sha(p('tools', file));
const provenance = {
  release: {
    product: 'Reveal AI',
    version: '1.3.2',
    packages: [
      { purl: 'pkg:maven/io.revealbi/reveal-sdk-ai@1.3.2?type=jar', repository: 'https://maven.revealbi.io/repository/public', publishedAt: '2026-11-19T22:11:57Z' },
      { purl: 'pkg:npm/reveal-sdk-node-ai@1.3.2', repository: 'https://registry.npmjs.org', publishedAt: '2026-11-19T22:06:32.552Z' },
    ],
    nativeSourceTag: 'v1.7.21-preview',
    nativeSourceCommit: '5ada28193ec979abc8a3c08c06a2e891af7f1983',
    sourceCommit: '7f5636e2c30bbfc616c2209b33c9b5d0ec36417b',
  },
  assessmentDate: DATE,
  tools: {
    syft: '1.57.2',
    mavenCycloneDX: '2.9.3',
    maven: '3.9.16',
    osvScanner: '2.7.1',
    node: 'v22.14.0',
    npm: '11.4.2',
    javap: '21.0.12.1',
    ilspycmd: '9.1.0.7988',
    ajv: '8.17.1',
  },
  toolArchives: [
    { file: 'apache-maven-3.9.16-bin.zip', sha256: toolHash('apache-maven-3.9.16-bin.zip'), verifiedAgainst: 'Apache .sha512' },
    { file: 'syft_1.57.2_windows_amd64.zip', sha256: toolHash('syft_1.57.2_windows_amd64.zip'), verifiedAgainst: 'syft_1.57.2_checksums.txt' },
    { file: 'osv-scanner_windows_amd64.exe', sha256: toolHash('osv-scanner_windows_amd64.exe'), verifiedAgainst: 'osv-scanner_SHA256SUMS (v2.7.1)' },
  ],
  schemas: ['bom-1.7.schema.json', 'spdx.schema.json', 'jsf-0.82.schema.json', 'cryptography-defs.schema.json']
    .map(file => ({ file, sha256: sha(p('tools', 'validate', 'schema-1.7.2', file)), source: 'CycloneDX/specification tag 1.7.2' })),
  artifacts,
  nugetPackages: [...nugetPackages.values()].sort((a, b) => a.file.localeCompare(b.file)),
  notes: [
    'The JAR and POM SHA-1 values were verified against the repository .sha1 files; Maven re-resolved the same JAR bytes.',
    'The npm tarball SHA-512 and SHA-1 were verified against registry dist.integrity and dist.shasum.',
    'The 42 bundled .NET assembly files are byte-identical in the JAR and the npm tarball.',
    'Every bundled third-party assembly and Reveal.Sdk.Dom matched the SHA-256 of the same file in the published NuGet package. The six Reveal.Sdk.AI assemblies carry the NuGet version and source commit but are a separate plugin build; see evidence/first-party-build-comparison.json.',
    'reveal-sdk-node 2.3.2 matched the SHA-256 recorded in the Reveal 2.3.2 assessment provenance.',
    'Maven, syft and OSV-Scanner downloads were checksum-verified against publisher checksum files; OSV database downloads were verified against the storage MD5 header.',
    'No Reveal product build was performed. Maven dependency/makeBom goals and npm install with scripts disabled were used.',
  ],
};
write(path.join(releaseDir, 'provenance.json'), provenance);

// ---------- evidence records ----------
const ev = (name, value) => write(path.join(evidenceRoot, 'evidence', name), value);
const sanitizedMap = Object.fromEntries(Object.entries(nativeMap).map(([k, v]) => {
  const { nuspec, packageFileFullPath, ...rest } = v;
  return [k, rest];
}));
ev('native-map.json', sanitizedMap);
ev('native-assembly-references.json', read(p('work', 'native-references.json')));

const bytecode = name => fs.readFileSync(p('work', 'bytecode', `${name}.javap.txt`), 'utf8');
const count = (text, pattern) => (text.match(pattern) ?? []).length;
const revealJars = ['reveal-sdk-ai-1.3.2', 'reveal-sdk-servlet-2.3.0', 'reveal-sdk-core-2.3.0'];
const checks = {
  defaultTyping: /DefaultTyping/g,
  polymorphicTypeValidator: /PolymorphicTypeValidator/g,
  jsonTypeInfo: /JsonTypeInfo/g,
  jacksonAnnotations: /Lcom\/fasterxml\/jackson\/annotation|com\/fasterxml\/jackson\/annotation\//g,
  mapperFeature: /MapperFeature/g,
  deserializationFeature: /DeserializationFeature/g,
  propertyNamingStrategy: /PropertyNamingStrateg/g,
  jsonView: /JsonView|withView/g,
  objectMapperConfigure: /ObjectMapper\.(configure|enable|disable|set[A-Z])/g,
  registerModule: /registerModule|findAndRegisterModules/g,
  readValueOrObjectReader: /ObjectMapper\.readValue|ObjectReader/g,
  inetAddress: /java\/net\/InetAddress|java\/net\/InetSocketAddress/g,
  xmlDatatype: /javax\/xml\/datatype/g,
  objectIdentity: /JsonIdentityInfo|jackson\/annotation\/ObjectId/g,
  nonBlockingParser: /NonBlocking|createNonBlocking|ByteArrayFeeder|ByteBufferFeeder/g,
  dataInput: /java\/io\/DataInput/g,
  numberInput: /jackson\/core\/io\/NumberInput/g,
  orgJson: /org\/json\//g,
  gzipHandler: /GzipHandler/g,
  securityHandler: /SecurityHandler/g,
  getTrailers: /getTrailers/g,
  http2Or3: /http2|HTTP2|http3|HTTP3/g,
};
const jackson = {};
for (const jar of revealJars) {
  const text = bytecode(jar);
  const methods = {};
  for (const m of text.matchAll(/Method com\/fasterxml\/jackson\/databind\/ObjectMapper\.([^ \n]+)/g)) methods[m[1]] = (methods[m[1]] ?? 0) + 1;
  jackson[jar] = {
    objectMapperMethodReferences: methods,
    absentApiReferenceCounts: Object.fromEntries(Object.entries(checks).map(([k, re]) => [k, count(text, re)])),
    javaRecords: [...text.matchAll(/^public final class (\S+) extends java\.lang\.Record/gm)].map(m => m[1]),
  };
}
ev('static-review.json', {
  method: 'javap -c -p -v disassembly of every class in the released Reveal JARs and of jackson-core/jackson-databind 2.17.2; string and member-reference inspection. No Reveal product code was executed.',
  revealJars: jackson,
  deserializationTargets: {
    'reveal-sdk-ai-1.3.2': ['ObjectMapper.readTree(String) -> JsonNode', 'ObjectMapper.convertValue(Object, LinkedHashMap<String,Object>)'],
    'reveal-sdk-core-2.3.0': ['ObjectMapper.readTree(String) -> JsonNode', 'ObjectMapper.convertValue(Object, ObjectNode.class)', 'ObjectMapper.convertValue(Object, Object.class)', 'ObjectMapper.convertValue(Object, HashMap.class)'],
  },
  jacksonLibrary: {
    looksLikeValidNumberInvocations: {
      'jackson-core-2.17.2': count(bytecode('jackson-core-2.17.2'), /invokestatic.*NumberInput\.looksLikeValidNumber/g),
      'jackson-databind-2.17.2': count(bytecode('jackson-databind-2.17.2'), /invokestatic.*NumberInput\.looksLikeValidNumber/g),
    },
    databindCreateNonBlockingReferences: count(bytecode('jackson-databind-2.17.2'), /createNonBlocking/g),
  },
  callbackServer: {
    'reveal-sdk-core-2.3.0 CallbackServer.start()': ['new Server()', 'new ServerConnector(Server)', 'ServerConnector.setPort(0)', 'Server.addConnector', 'Server.setHandler(CallbackServer$1)', 'Server.start()'],
    'reveal-sdk-core-2.3.2 CallbackServer.start()': ['new Server()', 'new ServerConnector(Server)', 'ServerConnector.setHost("127.0.0.1")', 'ServerConnector.setPort(0)', 'Server.addConnector', 'Server.setHandler(CallbackServer$1)', 'Server.start()'],
    'jetty-server 12.0.12 ServerConnector.openAcceptChannel()': 'getHost() == null -> new InetSocketAddress(port) (wildcard address) -> ServerSocketChannel.bind',
    'reveal-sdk-core 2.3.0 CallbackServer$1.handle()': 'Compares the RevealBI-Auth header with callbackAuth before any path routing; on mismatch logs an error, sets 404 and returns. /lifecycle-ready and every provider route are after the check.',
    'callbackAuth source': 'RevealServer.start(): UUID.randomUUID().toString(), passed to the CallbackServer constructor.',
    'core classes differing between 2.3.0 and 2.3.2': ['RevealSettings', 'impl.CallbackServer', 'impl.CallbackServer$1', 'impl.EngineProcessHandler', 'impl.exporter.DefaultDashboardExporter', 'impl.exporter.DefaultDashboardExporter$TemporaryFileInputStream (2.3.0 only)'],
    jettyClientUsers: ['io.revealbi.core.impl.EngineClient (fixed http://127.0.0.1:<port> engine URLs)'],
  },
  orgJsonReferencesInGraphJars: Object.fromEntries(fs.readdirSync(p('dl', 'java', 'deps')).filter(f => f.endsWith('.jar') && f !== 'json-20231013.jar').sort().map(f => [f, 0])),
});
ev('first-party-build-comparison.json', {
  description: 'The six Reveal.Sdk.AI assemblies bundled in the JAR/tarball compared with the same files in the published 1.7.21-preview NuGet packages.',
  informationalVersion: '1.7.21-preview+5ada28193e (identical in both builds)',
  assemblyConfiguration: 'Release (both builds)',
  decompiler: 'ilspycmd 9.1.0.7988, both builds decompiled with the bundled native/ folder as the reference path',
  observedDifferences: [
    'ThisAssembly.IsPublicRelease: false in the bundled build, true in the NuGet build.',
    'Reveal.Sdk.AI and Reveal.Sdk.AI.AspNetCore: different RootNamespace constant and InternalsVisibleTo target (plugin build variant).',
    'The plugin variant references Reveal.Sdk.AI.Abstractions.Debug (bundled) instead of the Reveal.Sdk.AI.Abstractions package.',
  ],
  assemblies: Object.values(nativeMap).filter(e => e.hashMatch === false).map(e => ({
    id: e.id, version: e.version, bundledFile: e.file, bundledSha256: e.sha256,
    nugetFile: e.packagePath, nugetSha256: sha(e.packageFileFullPath),
  })),
});
const lock232 = read(p('ref232', 'projects', 'node', 'package-lock.json')).packages;
const lockAi = read(p('dl', 'node', 'install', 'package-lock.json')).packages;
ev('npm-chain-comparison.json', {
  description: 'Packages on the vulnerable npm chains compared with the Reveal 2.3.2 assessment lockfile.',
  revealSdkNode: { version: '2.3.2', sha256: sha(p('dl', 'node', 'ref', 'reveal-sdk-node-2.3.2.tgz')), matches232Provenance: true },
  packages: ['basic-ftp', 'get-uri', 'pac-proxy-agent', 'proxy-agent', '@puppeteer/browsers', 'extract-zip', 'puppeteer-core', 'chromium-bidi', 'zod'].map(name => {
    const key = `node_modules/${name}`;
    return { name, version: lockAi[key].version, integrity: lockAi[key].integrity, identicalTo232: lockAi[key].version === lock232[key]?.version && lockAi[key].integrity === lock232[key]?.integrity };
  }),
  revealCallSites: {
    'reveal-sdk-node 2.3.2 lib/exporter/PuppeteerUtils.js': "buildId = '132.0.6834.110'",
    'reveal-sdk-node 2.3.2 lib/reveal.js': 'puppeteer.launch({ executablePath: executablePath, args: launchArgs})',
    'reveal-sdk-node-ai 1.3.2 index.js': "require('fs'), require('path') only",
  },
  fixAvailability: {
    'basic-ftp': 'Fixed in 6.2.1/6.2.3/6.2.4 (latest 6.2.6); get-uri 6.0.5 requires ^5.0.2.',
    'extract-zip': 'No fixed release (last_affected 2.0.1).',
    zod: 'Fixed in 4.6.6; chromium-bidi 14.0.0 requires ^3.24.1.',
  },
});

// ---------- projects and generation inputs ----------
copy(p('work', 'java', 'project', 'pom.xml'), path.join(evidenceRoot, 'projects', 'java', 'pom.xml'));
copy(p('work', 'java', 'project', 'settings.xml'), path.join(evidenceRoot, 'projects', 'java', 'settings.xml'));
write(path.join(evidenceRoot, 'projects', 'java', 'dependency-tree-host-activated.txt'), fs.readFileSync(p('work', 'java', 'tree-host.txt'), 'utf8'));
copy(p('dl', 'node', 'install', 'package.json'), path.join(evidenceRoot, 'projects', 'node', 'package.json'));
copy(p('dl', 'node', 'install', 'package-lock.json'), path.join(evidenceRoot, 'projects', 'node', 'package-lock.json'));
for (const f of ['reveal-sdk-ai-1.3.2.pom', 'reveal-sdk-servlet-2.3.0.pom', 'reveal-sdk-core-2.3.0.pom', 'reveal-sdk-root-2.3.0.pom']) copy(p('dl', 'java', f), path.join(evidenceRoot, 'evidence', f));
for (const f of ['map-native.mjs', 'assemble.mjs', 'validate.mjs', 'validate-catalog.cjs', 'check-page.mjs', 'package-release.mjs', 'commands.md']) copy(p('scripts', f), path.join(evidenceRoot, 'generation', f));
ev('validation-results.json', read(p('work', 'validation-results.json')));

// ---------- combined archive staging (zipped by the caller) ----------
for (const platform of ['java', 'node']) {
  const rel = path.join('reveal-ai', platform, '1.3.2', `reveal-sdk-ai-${platform}-1.3.2.cdx.json`);
  copy(p('staging', 'files', rel), path.join(combinedRoot, 'files', rel));
}
for (const f of ['vex-assessments.json', 'scan-summary.json', 'provenance.json', 'README.md']) copy(path.join(releaseDir, f), path.join(combinedRoot, f));

// Leak check: no local user paths or private source-repository links in anything staged for publication.
const userName = os.userInfo().username.toLowerCase();
for (const dir of [evidenceRoot, combinedRoot]) {
  for (const file of fs.readdirSync(dir, { recursive: true }).map(f => path.join(dir, f)).filter(f => fs.statSync(f).isFile())) {
    const text = fs.readFileSync(file, 'utf8');
    const lower = text.toLowerCase();
    if (lower.includes(userName) || lower.includes(root.toLowerCase()) || lower.includes(rootPosix.toLowerCase()) || /github\.com\/[^/\s"]+\/Reveal\.Sdk\.AI(\.git)?["\s]/i.test(text)) {
      throw new Error(`Local path or private link in ${file}`);
    }
  }
}
console.log(JSON.stringify({ documents, states, databases: databases.map(d => d.ecosystem), artifacts: artifacts.length, nugetPackages: nugetPackages.size }, null, 2));
