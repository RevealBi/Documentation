import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const write=(p,d)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(d,null,2)+'\n');};
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const date=new Date().toISOString();
const prop=(name,value)=>({name:`io.revealbi.sbom.${name}`,value});
const generated=[];
function save(relative,doc,scope){
  const normalizeReferences=value=>{if(!value||typeof value!=='object')return;for(const [k,v] of Object.entries(value)){if(k==='url'&&typeof v==='string'&&v.startsWith('git+'))value[k]=v.slice(4);else normalizeReferences(v);}};
  normalizeReferences(doc);
  doc.specVersion='1.7';doc.version=1;doc.serialNumber=`urn:uuid:${crypto.randomUUID()}`;
  doc.metadata.timestamp=date;doc.metadata.manufacturer={name:'Infragistics, Inc.'};
  doc.metadata.properties=[...(doc.metadata.properties??[]),prop('release','2.3.2'),prop('inventory-scope',scope),prop('publication-status','Draft; release-owner approval pending')];
  const all=[doc.metadata.component,...(doc.components??[])];
  const refs=new Set(all.map(c=>c['bom-ref']));
  if(refs.size!==all.length) throw new Error(`Duplicate component reference ${relative}`);
  for(const d of doc.dependencies??[]) for(const r of [d.ref,...(d.dependsOn??[])]) if(!refs.has(r)) throw new Error(`Dangling reference ${relative}: ${r}`);
  write(`out/files/${relative}`,doc);generated.push({file:relative,components:doc.components?.length??0});
}
for(const name of [...read('evidence/nuget-packages.json'),'reveal-server-dotnet-all-connectors']) {
  const doc=read(`raw/${name}.cdx.json`);
  if(name.startsWith('Reveal.')){
    const root=doc.components.find(c=>c.name===name&&c.version==='2.3.2');
    if(!root) throw new Error(`Missing package ${name}`);
    const oldRef=doc.metadata.component['bom-ref'];doc.metadata.component=root;
    doc.components=doc.components.filter(c=>c!==root);
    doc.dependencies=doc.dependencies.filter(d=>d.ref!==oldRef);
    root.externalReferences??=[];root.externalReferences.push({type:'distribution',url:`https://www.nuget.org/packages/${name}/2.3.2`});
  }else{doc.metadata.component.name='Reveal Server .NET all connectors';doc.metadata.component.version='2.3.2';}
  const folder=name.startsWith('Reveal.Sdk.Data.')?'connectors/':name==='Reveal.Sdk.Cache.Redis'?'packages/':'';
  save(`reveal-server/dotnet/2.3.2/${folder}${name}-2.3.2.cdx.json`,doc,'Published NuGet package dependency graph resolved for net8.0; development dependencies excluded. Framework-provided and build-only packages may appear in the restore graph.');
}
function npmRoot(doc,name){
 const meta=read(`evidence/${name}-metadata.json`),root=doc.metadata.component;
 root.hashes=[{alg:'SHA-256',content:hash(`artifacts/${name}-2.3.2.tgz`)},{alg:'SHA-512',content:Buffer.from(meta.dist.integrity.slice(7),'base64').toString('hex')}];
 root.externalReferences=[{type:'distribution',url:meta.dist.tarball}];root.supplier={name:'Infragistics, Inc.'};
 root.properties??=[];root.properties.push(prop('npm-integrity',meta.dist.integrity));
}
const client=read('raw/client.cdx.json');npmRoot(client,'reveal-sdk');
save('reveal-client/javascript/2.3.2/reveal-sdk-client-2.3.2.cdx.json',client,'Published npm runtime dependency manifest. The prebundled browser implementation and its build-time inputs are not individually inventoried; zero package matches is not a complete audit of bundled JavaScript.');
function addEngine(doc,key,distribution,rid){
  const deps=read(`evidence/engines/${key}/RevealEnginePrg.deps.json`),bundle=read(`evidence/engines/${key}/bundle.json`);
  const target=deps.targets[deps.runtimeTarget.name], refs=new Map(),byName=new Map();
  const engineRef=`pkg:generic/RevealEnginePrg@2.3.2?arch=x86_64&distribution=${distribution}&os=${rid==='win-x64'?'windows':'linux'}`;
  doc.components.push({type:'application',name:'RevealEnginePrg',version:'2.3.2','bom-ref':engineRef,purl:engineRef,supplier:{name:'Infragistics, Inc.'},hashes:[{alg:'SHA-256',content:bundle.sha256},{alg:'SHA-512',content:bundle.sha512}],properties:[prop('runtime',rid),prop('deps-sha256',hash(`evidence/engines/${key}/RevealEnginePrg.deps.json`))]});
  for(const [id,lib] of Object.entries(deps.libraries)){
    const slash=id.lastIndexOf('/'),originalName=id.slice(0,slash),version=id.slice(slash+1);
    const name=originalName.replace(/^runtimepack\./,'');
    const ecosystem=['package','runtimepack'].includes(lib.type)?'nuget':'generic';
    const ref=`pkg:${ecosystem}/${name}@${version}`;refs.set(id,ref);byName.set(originalName,ref);
    const component={type:lib.type==='runtimepack'?'framework':'library',name,version,'bom-ref':ref,purl:ref,properties:[prop('deps-library-type',lib.type)]};
    if(lib.sha512?.startsWith('sha512-')) component.hashes=[{alg:'SHA-512',content:Buffer.from(lib.sha512.slice(7),'base64').toString('hex')}];
    doc.components.push(component);
  }
  for(const [id,lib] of Object.entries(target)){
    const children=Object.entries(lib.dependencies??{}).map(([name,version])=>{
      const ref=refs.get(`${name}/${version}`)??byName.get(name);
      if(!ref) throw new Error(`Missing dependency ${key} ${name}/${version}`);return ref;
    });
    doc.dependencies.push({ref:refs.get(id),dependsOn:[...new Set(children)]});
  }
  const nativeRoot=doc.dependencies.find(d=>d.ref===engineRef);
  if(!nativeRoot) doc.dependencies.push({ref:engineRef,dependsOn:[...refs.values()]});
  const rootRef=doc.metadata.component['bom-ref'];
  const rootDep=doc.dependencies.find(d=>d.ref===rootRef);
  rootDep.dependsOn??=[];rootDep.dependsOn.push(engineRef);
  doc.metadata.component.properties??=[];doc.metadata.component.properties.push(prop('runtime',rid),prop('architecture','x86_64'));
}
for(const [rid,platform] of [['win-x64','windows-x86_64'],['linux-x64','linux-x86_64']]){
  const node=read('raw/node.cdx.json');npmRoot(node,'reveal-sdk-node');addEngine(node,`node-${rid}`,'node',rid);
  save(`reveal-server/node/2.3.2/reveal-sdk-node-${rid}-2.3.2.cdx.json`,node,'Published npm runtime dependencies resolved at generation time plus the separately distributed engine embedded .deps.json. Optional downloaded Chromium and host operating-system libraries require separate assessment.');
  const java=read(`raw/java-${platform}.json`);
  const expectedEngine=`reveal-sdk-engine-${platform}`;
  const correctEngineRef=java.components.find(c=>c.name===expectedEngine)['bom-ref'];
  const hostEngineRefs=java.components.filter(c=>c.name.startsWith('reveal-sdk-engine-')&&c.name!==expectedEngine).map(c=>c['bom-ref']);
  java.components=java.components.filter(c=>!hostEngineRefs.includes(c['bom-ref']));
  java.dependencies=java.dependencies.filter(d=>!hostEngineRefs.includes(d.ref)).map(d=>({...d,dependsOn:[...new Set((d.dependsOn??[]).map(r=>hostEngineRefs.includes(r)?correctEngineRef:r))]}));
  java.metadata.properties??=[];java.metadata.properties.push(prop('platform-resolution','Explicit target engine selected; host-activated engine dependency replaced for cross-platform resolution.'));
  java.metadata.component.name='Reveal Java SDK';java.metadata.component.version='2.3.2';
  java.metadata.component.externalReferences=[{type:'distribution',url:'https://maven.revealbi.io/repository/public/io/revealbi/reveal-sdk-servlet/2.3.2/reveal-sdk-servlet-2.3.2.jar'}];
  addEngine(java,`java-${platform}`,'java',rid);
  save(`reveal-server/java/2.3.2/reveal-sdk-java-${platform}.cdx.json`,java,'Published Maven compile/runtime dependencies resolved at generation time, plus the engine embedded .deps.json. Provided servlet API and host operating-system libraries are excluded. Jackson uses the released POM range [2.13,3.0).');
}
write('evidence/generated.json',{timestamp:date,documents:generated});
console.log(JSON.stringify(generated,null,2));
