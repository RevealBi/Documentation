import fs from 'node:fs';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import path from 'node:path';
import {createRequire} from 'node:module';
const require = createRequire(import.meta.url);
const signature = Buffer.from('8b1202b96a612038727b930214d7a03213f5b9e6efae3318ee3b2dce24b36aae','hex');
function extract(buffer, key) {
  const marker = buffer.indexOf(signature);
  if(marker<8) throw new Error(`No .NET bundle marker: ${key}`);
  let pos=Number(buffer.readBigInt64LE(marker-8));
  const u32=()=>{const n=buffer.readUInt32LE(pos);pos+=4;return n;};
  const i64=()=>{const n=Number(buffer.readBigInt64LE(pos));pos+=8;return n;};
  const str=()=>{let length=0,shift=0,b;do{b=buffer[pos++];length|=(b&127)<<shift;shift+=7;}while(b&128);const s=buffer.toString('utf8',pos,pos+length);pos+=length;return s;};
  const major=u32(),minor=u32(),count=u32(),id=str();
  if(major!==6) throw new Error(`Unexpected bundle version ${major}`);
  const depsOffset=i64(),depsSize=i64(),configOffset=i64(),configSize=i64(),flags=i64();
  const entries=[];
  for(let i=0;i<count;i++) entries.push({offset:i64(),size:i64(),compressedSize:i64(),type:buffer[pos++],path:str()});
  fs.mkdirSync(`evidence/engines/${key}`,{recursive:true});
  const apiReferences=[];
  for(const item of entries.filter(e=>e.path.endsWith('.dll'))){
    const bytes=buffer.subarray(item.offset,item.offset+(item.compressedSize||item.size));
    const content=item.compressedSize?zlib.inflateRawSync(bytes):bytes;
    const hits=['EnvelopedCms','SignedCms','XmlLayout','XmlLayoutSchemaLog4J','WriteToDirectory','SnappyStream','set_SslMode'].filter(s=>content.includes(Buffer.from(s)));
    if(hits.length)apiReferences.push({file:item.path,sha256:crypto.createHash('sha256').update(content).digest('hex'),hits});
  }
  fs.writeFileSync(`evidence/engines/${key}/api-references.json`,JSON.stringify(apiReferences,null,2)+'\n');
  for(const item of entries.filter(e=>e.path.endsWith('.json'))) {
    const bytes=buffer.subarray(item.offset,item.offset+(item.compressedSize||item.size));
    const content=item.compressedSize?zlib.inflateRawSync(bytes):bytes;
    if(content.length!==item.size) throw new Error(`Size mismatch ${item.path}`);
    const root=path.resolve(`evidence/engines/${key}`);
    const destination=path.resolve(root,item.path);
    if(!destination.startsWith(root+path.sep)) throw new Error('Unsafe bundle entry');
    fs.mkdirSync(path.dirname(destination),{recursive:true});
    fs.writeFileSync(destination,content);
  }
  fs.writeFileSync(`evidence/engines/${key}/bundle.json`,JSON.stringify({major,minor,count,id,depsOffset,depsSize,configOffset,configSize,flags,sha256:crypto.createHash('sha256').update(buffer).digest('hex'),sha512:crypto.createHash('sha512').update(buffer).digest('hex'),entries},null,2)+'\n');
  console.log(key,count,'files');
}
for(const rid of ['win-x64','linux-x64']) extract(zlib.gunzipSync(fs.readFileSync(`artifacts/node-${rid}.gz`)),`node-${rid}`);
if(fs.existsSync('tools/node_modules/adm-zip')) {
  const Zip=require('./tools/node_modules/adm-zip');
  for(const platform of ['windows-x86_64','linux-x86_64']) {
    const zip=new Zip(`artifacts/java-${platform}.jar`);
    const engine=zip.getEntries().find(e=>/RevealEnginePrg(?:\.exe)?$/.test(e.entryName));
    if(!engine) throw new Error('No Java engine found');
    extract(engine.getData(),`java-${platform}`);
  }
}
