import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),Zip=require('./tools/node_modules/adm-zip'),Ajv=require('./tools/node_modules/ajv/dist/2020');
const repo=path.resolve('../../..'),root=path.join(repo,'static/sbom'),release=path.join(repo,'scripts/sbom/releases/2.3.2');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const ajv=new Ajv({strict:false,allErrors:true});
const validateCatalog=ajv.compile(read(path.join(root,'catalog.schema.json'))),validateManifest=ajv.compile(read(path.join(root,'bundle-manifest.schema.json')));
const catalog=read(path.join(root,'catalog.json'));
assert.ok(validateCatalog(catalog),JSON.stringify(validateCatalog.errors));
let bundles=0,documents=0;
for(const entry of catalog.entries){
 const bytes=fs.readFileSync(path.join(root,entry.downloadUrl));assert.equal(hash(bytes),entry.sha256,entry.id);
 if(entry.artifactType!=='bundle')continue;
 const zip=new Zip(bytes),manifest=JSON.parse(zip.readAsText('manifest.json'));
 assert.ok(validateManifest(manifest),JSON.stringify(validateManifest.errors));
 for(const file of manifest.files){
  const data=zip.readFile(file.archivePath);assert.equal(hash(data),file.sha256,`${entry.id}/${file.archivePath}`);
  if(entry.packageVersion==='2.3.2'){
   const source=path.join(root,'files/reveal-server',entry.platform,'2.3.2',file.archivePath.slice(6));
   assert.equal(hash(fs.readFileSync(source)),file.sha256,source);documents++;
  }
 }
 if(entry.packageVersion==='2.3.2')bundles++;
}
assert.equal(bundles,3);assert.equal(documents,41);
for(const f of read(path.join(release,'checksums.json')).files)assert.equal(hash(fs.readFileSync(path.join(release,f.file))),f.sha256,f.file);
const archive=new Zip(path.join(release,'reveal-2.3.2-sbom-vex.zip'));
const sboms=archive.getEntries().filter(e=>e.entryName.endsWith('.cdx.json'));
assert.equal(sboms.length,42);
let statements=0;
for(const file of sboms){
 const d=JSON.parse(file.getData().toString());statements+=(d.vulnerabilities??[]).length;
 assert.equal(hash(file.getData()),hash(fs.readFileSync(path.join(root,file.entryName))));
}
assert.equal(statements,187);
const scan=JSON.parse(archive.readAsText('osv-results.json'));
assert.equal(scan.results.length,41);
const result={documents:42,embeddedVexStatements:statements,newBundles:bundles,catalogEntries:catalog.entries.length,schemaValidation:'passed',catalogAndManifestHashes:'passed',combinedArchive:'passed',mavenMatchingRegressionTests:2};
fs.writeFileSync('evidence/validation-results.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
