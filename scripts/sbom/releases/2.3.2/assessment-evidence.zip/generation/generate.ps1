$ErrorActionPreference = 'Stop'
$work = $PSScriptRoot
$env:NUGET_PACKAGES = Join-Path $work 'nuget'
New-Item -ItemType Directory -Force "$work/raw", "$work/logs" | Out-Null
$packages = Get-Content "$work/evidence/nuget-packages.json" -Raw | ConvertFrom-Json
$jobs = @($packages) + 'reveal-server-dotnet-all-connectors'
$results = $jobs | ForEach-Object -Parallel {
    $name = $_
    $taskRoot = $using:work
    $project = "$taskRoot/projects/dotnet/$name/$name.csproj"
    $log = "$taskRoot/logs/$name.log"
    & dotnet restore $project --configfile "$taskRoot/projects/dotnet/NuGet.Config" --packages "$taskRoot/nuget" --verbosity quiet *> $log
    if ($LASTEXITCODE -ne 0) { return "$name restore FAILED" }
    & "$taskRoot/tools/dotnet-CycloneDX.exe" $project -dpr -ed -F Json -spv 1.7 -o "$taskRoot/raw" -fn "$name.cdx.json" *> "$taskRoot/logs/$name-cdx.log"
    if ($LASTEXITCODE -ne 0) { return "$name SBOM FAILED" }
    return "$name OK"
} -ThrottleLimit 4
$results
if ($results -match 'FAILED') { throw 'One or more NuGet SBOMs failed; see logs.' }
foreach($platform in @('client','node')) {
    Push-Location "$work/projects/$platform"
    try {
        & npm install --ignore-scripts --omit=dev --no-audit --no-fund *> "$work/logs/npm-$platform.log"
        if ($LASTEXITCODE -ne 0) { throw "npm $platform failed" }
        & "$work/tools/node_modules/.bin/cyclonedx-npm.cmd" --omit dev --spec-version 1.7 --output-file "$work/raw/$platform.cdx.json" *> "$work/logs/npm-$platform-cdx.log"
        if ($LASTEXITCODE -ne 0) { throw "npm $platform SBOM failed" }
    } finally { Pop-Location }
}
foreach($platform in @('windows-x86_64','linux-x86_64')) {
    & "$work/tools/apache-maven-3.9.11/bin/mvn.cmd" -B -f "$work/projects/java-$platform/pom.xml" "-Dmaven.repo.local=$work/maven-cache" '-P!windows-amd64,!windows-x86,!windows-aarch64,!linux-amd64,!linux-x86,!linux-aarch64,!mac-aarch64,!mac-x86_64' org.cyclonedx:cyclonedx-maven-plugin:2.9.3:makeBom '-DincludeTestScope=false' '-DincludeProvidedScope=false' '-DoutputFormat=json' "-DoutputDirectory=$work/raw" "-DoutputName=java-$platform" *> "$work/logs/maven-$platform.log"
    if ($LASTEXITCODE -ne 0) { throw "Maven $platform SBOM failed" }
}
