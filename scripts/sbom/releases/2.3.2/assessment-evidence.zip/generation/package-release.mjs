import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url), Zip=require('./tools/node_modules/adm-zip');
const repo=path.resolve('../../..'),release=path.join(repo,'scripts/sbom/releases/2.3.2');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const write=(p,d)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(d,null,2)+'\n');};
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);
const assessment=read('evidence/vex-assessments.json'),coverage=read('evidence/scan-coverage.json');
const format={name:'CycloneDX',version:'1.7',mediaType:'application/vnd.cyclonedx+json'};
fs.mkdirSync(release,{recursive:true});
const readme=`# Reveal 2.3.2 SBOM and VEX assessment

Generated on November 13, 2026 from published release artifacts. **Draft: release-owner approval is required before publication** under [the SBOM maintenance process](../../README.md).

The assessment contains **42 CycloneDX 1.7 SBOMs**, **187 embedded VEX statements**, and **29 distinct package/version/advisory decisions**: **23 not affected, 1 exploitable, and 5 in triage**. These are package-version decisions; the five triage decisions cover four distinct advisories. Findings are repeated in the SBOMs where their components occur.

## Coverage

| Distribution | Documents |
| --- | ---: |
| .NET: ASP.NET, Data, 33 connectors, Redis cache, all-connectors aggregate | 37 |
| Java: Windows x64 and Linux x64 | 2 |
| Node: Windows x64 and Linux x64 | 2 |
| JavaScript browser npm package | 1 |

The NuGet graphs target net8.0. npm and Maven ranges were resolved on the assessment date, so a later install can select different dependencies. Jackson resolved to 2.23.0 (annotations 2.23). The four downloaded engines embed .NET 8.0.34. The Java Linux graph explicitly selects the Linux engine in place of Maven's host-activated Windows engine.

## Findings requiring action

| Status | Component | Advisory | Action |
| --- | --- | --- | --- |
| Exploitable (conservative assessment) | Microsoft.Identity.Client 4.56.0, standalone Analysis Services connector | [GHSA-m5vv-6r4h-3vj9](https://github.com/advisories/GHSA-m5vv-6r4h-3vj9) | Update the connector dependency chain to a supported patched MSAL release. The all-connectors graph and packaged engines select 4.80.0. |
| In triage | System.Security.Cryptography.Pkcs 8.0.0 and 8.0.1 | [GHSA-846f-f764-76mx](https://github.com/advisories/GHSA-846f-f764-76mx) | Upgrade to 8.0.2 or a supported patched release, or establish whether SQL Client signature verification can process attacker-controlled data in supported configurations. |
| In triage | basic-ftp 5.3.1, Node runtime graph | [GHSA-5pm8-86m8-9m6r](https://github.com/advisories/GHSA-5pm8-86m8-9m6r), [GHSA-c475-qrg2-pj4r](https://github.com/advisories/GHSA-c475-qrg2-pj4r), [GHSA-r4jh-29pc-gfqr](https://github.com/advisories/GHSA-r4jh-29pc-gfqr) | Review FTP-backed PAC proxy configuration and update the transitive dependency when patched. The downloader honors deployment proxy settings, so FTP reachability cannot be ruled out universally. |

All 29 decisions, their scope, rationale, and affected documents are recorded in [vex-assessments.json](./vex-assessments.json). A not-affected decision is conditional on the stated runtime, code path, or configuration; it does not mean the upstream component is fixed. This is a static artifact/configuration assessment, not an exploit test or penetration test.

## Scan and verification

OSV-Scanner 2.7.1 used complete NuGet, npm, and Maven all.zip databases downloaded on November 13, 2026, with --offline --no-resolve --no-ignore --all-packages. No package inventory was sent to an advisory service. The scan log records 42 successful extractions; 41 documents have package results and the browser manifest has zero dependency components. OSV filtered 320 local/unscannable component occurrences. [scan-summary.json](./scan-summary.json) records coverage and database SHA-256 hashes.

All 42 new SBOMs were validated against the official CycloneDX 1.7 JSON schema, and their dependency and VEX references were checked. Bundle manifests and the catalog were validated against the repository schemas, and every stored SHA-256 was recomputed. Historical SBOMs and their decisions were preserved. The VEX application tool was corrected to match Maven group:artifact names from OSV 2.7.1; regression checks cover namespace isolation and legacy names.

## Limits

- The browser SBOM inventories its published npm runtime manifest, which declares no dependencies. Prebundled JavaScript subcomponents/build inputs were not independently identified. Its no-match result is **not a full security assessment of bundled browser code**.
- The scan covers package identities supported by OSV. Generic first-party assemblies, host OS libraries, separately downloaded Chrome Headless Shell (the Node exporter selects 132.0.6834.110), and software supplied by the host application need separate assessment.
- Windows/Linux x64 follow the existing catalog coverage. ARM64 and macOS distributions are not included. Reveal AI is independently versioned and is outside this release.
- NuGet decisions assume a serviced .NET 8 host. Custom providers, host logging layouts, proxy settings, and browser protocol choices can change exposure.

## Reproduction and evidence

[provenance.json](./provenance.json) records release identity and artifact hashes. assessment-evidence.zip retains the scan output/log, package lockfiles, embedded engine dependency manifests, static API-reference summaries, and generation/validation scripts. Large binaries, databases, tool installations, and full decompiled proprietary source remain in the local generation cache and are not included.

The complete reveal-2.3.2-sbom-vex.zip contains all 42 SBOMs, the three platform bundles, assessment records, and evidence. Its osv-results.json uses portable files/... paths. To reapply decisions after extracting it, run the repository's apply-vex.mjs with --scan osv-results.json --assessments vex-assessments.json --sbom-root files from the extracted directory. Use a fresh scan when package versions, code paths, or database snapshots change; do not reuse an old clean result.
`;
fs.writeFileSync(path.join(release,'README.md'),readme);
write(path.join(release,'vex-assessments.json'),assessment);
write(path.join(release,'scan-summary.json'),coverage);
const releaseMeta=read('evidence/github-release.json');
const artifacts=walk('artifacts').filter(p=>/\.(tgz|gz|jar)$/.test(p));
for(const name of read('evidence/nuget-packages.json'))artifacts.push(`nuget/${name.toLowerCase()}/2.3.2/${name.toLowerCase()}.2.3.2.nupkg`);
const provenance={release:{version:'2.3.2',url:releaseMeta.html_url,publishedAt:releaseMeta.published_at},assessmentDate:assessment.assessment.date,tools:{dotnetCycloneDX:'6.2.0',npmCycloneDX:'6.0.1',mavenCycloneDX:'2.9.3',maven:'3.9.11',osvScanner:'2.7.1',node:process.version},artifacts:artifacts.map(file=>({file:file.replaceAll('\\','/'),bytes:fs.statSync(file).size,sha256:hash(file)})),schemas:['bom-1.7','spdx','jsf-0.82','cryptography-defs'].map(name=>({file:`${name}.schema.json`,sha256:hash(`tools/${name}.schema.json`)})),notes:['npm tarball SHA-512 integrity values were verified against registry metadata.','OSV and Maven executables/archives were checksum-verified against publisher checksum files.','cryptography-defs schema was supplied by the pinned CycloneDX npm library; other schema files were downloaded from the official CycloneDX specification repository.','No Reveal product build was performed. NuGet restore and reference resolution, Maven dependency/SBOM goals, and npm install with scripts disabled were used.']};
write(path.join(release,'provenance.json'),provenance);
const portableScan=read('evidence/osv-results.json');
for(const r of portableScan.results)r.source.path='files/'+path.relative(path.resolve('out/files'),r.source.path).replaceAll('\\','/');
const evidenceZip=new Zip();
evidenceZip.addFile('osv-results.json',Buffer.from(JSON.stringify(portableScan,null,2)+'\n'));
evidenceZip.addFile('osv-scan.log',Buffer.from(fs.readFileSync('logs/osv-scan.log','utf8').split(path.resolve('.')).join('${WORKDIR}')));
for(const file of ['evidence/findings.json','evidence/scan-coverage.json','evidence/runtime-api-references.json','evidence/reveal-sdk-core-2.3.2.pom','evidence/reveal-sdk-servlet-2.3.2.pom',...walk('evidence/engines'),...walk('projects').filter(p=>p.endsWith('packages.lock.json')||p.endsWith('package-lock.json')&&!p.includes('node_modules')||p.endsWith('.csproj')||p.endsWith('pom.xml'))]){
 if(file.endsWith('bundle.json'))continue;
 evidenceZip.addLocalFile(file,path.dirname(file).replaceAll('\\','/'));
}
for(const file of ['prepare.mjs','generate.ps1','extract-engines.mjs','assemble.mjs','assess.mjs','validate.mjs','verify-release.mjs','package-release.mjs'])evidenceZip.addLocalFile(file,'generation');
evidenceZip.addLocalFile('evidence/validation-results.json','evidence');
evidenceZip.addFile('evidence/static-review.json',Buffer.from(JSON.stringify({method:'Released artifact decompilation, bytecode inspection, and managed metadata string-reference inspection.',nugetDataCopyLocalAssemblyCount:143,absentLegacyCopyLocalAssemblies:['System.Formats.Asn1.dll','System.Net.Http.dll','System.Text.RegularExpressions.dll'],javaJarReferences:{orgJson:[],JSONTokener:[],GzipHandler:[],PathMapped:[],getTrailers:[]},reviewNotes:assessment.decisions.map(d=>({package:d.package,version:d.version,advisory:d.advisory,detail:d.analysis.detail}))},null,2)));
evidenceZip.writeZip(path.join(release,'assessment-evidence.zip'));
const newEntries=[];
for(const platform of ['dotnet','java','node']){
 const source=`out/files/reveal-server/${platform}/2.3.2`,files=walk(source).filter(p=>p.endsWith('.cdx.json')).sort();
 const label={dotnet:'.NET',java:'Java',node:'Node'}[platform];
 const description=platform==='dotnet'?'ASP.NET SDK, Data, 33 connectors, Redis cache, and all-connectors aggregate':'Windows x64 and Linux x64';
 const id=`reveal-server-2.3.2-${platform}`;
 const manifest={schemaVersion:1,bundle:{id,product:'Reveal Server',packageVersion:'2.3.2',platform,platformLabel:label,description},format,files:files.map(f=>{
  const rel=path.relative(source,f).replaceAll('\\','/'),name=path.basename(f).replace('-2.3.2.cdx.json','');
  if(platform==='dotnet')return {displayName:name,kind:rel.startsWith('connectors/')?'connector':rel.startsWith('packages/')?'package':rel.startsWith('reveal-server')?'aggregate':'base',archivePath:'sboms/'+rel,mediaType:format.mediaType,sha256:hash(f),...(rel.includes('/')?{packageName:name}:{})};
  const architecture=/win|windows/.test(rel)?'win-x64':'linux-x64';
  return {displayName:`Reveal ${label} SDK ${architecture==='win-x64'?'Windows':'Linux'} x64`,kind:'runtime',archivePath:'sboms/'+rel,mediaType:format.mediaType,sha256:hash(f),architecture,architectureLabel:architecture==='win-x64'?'Windows x64':'Linux x64'};
 })};
 const zip=new Zip();zip.addFile('manifest.json',Buffer.from(JSON.stringify(manifest,null,2)+'\n'));
 zip.addFile('README.txt',Buffer.from(`Reveal 2.3.2 ${label} SBOMs\n\nDraft: release-owner approval is pending. Each SBOM includes an embedded CycloneDX VEX assessment. Review vulnerabilities[].analysis and metadata.properties for assessment scope and limitations. Some findings remain exploitable or in_triage. These files do not certify an application deployment.\n`));
 files.forEach((f,i)=>zip.addFile(manifest.files[i].archivePath,fs.readFileSync(f)));
 const relative=`bundles/reveal-server/${platform}/2.3.2/reveal-server-${platform}-2.3.2-sbom.zip`,dest=path.join(repo,'static/sbom',relative);
 fs.mkdirSync(path.dirname(dest),{recursive:true});zip.writeZip(dest);
 newEntries.push({id,product:'Reveal Server',packageVersion:'2.3.2',scope:'server',platform,platformLabel:label,contentsLabel:description,artifactType:'bundle',downloadUrl:'./'+relative,mediaType:'application/zip',sha256:hash(dest)});
}
for(const f of walk('out/files')){const rel=path.relative('out/files',f),dest=path.join(repo,'static/sbom/files',rel);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(f,dest);}
const client='files/reveal-client/javascript/2.3.2/reveal-sdk-client-2.3.2.cdx.json';
newEntries.push({id:'reveal-client-2.3.2-javascript',product:'Reveal Client',packageVersion:'2.3.2',scope:'client',platform:'javascript',platformLabel:'JavaScript',contentsLabel:'Browser npm runtime dependency manifest',artifactType:'file',downloadUrl:'./'+client,mediaType:format.mediaType,sha256:hash(path.join(repo,'static/sbom',client))});
const catalogPath=path.join(repo,'static/sbom/catalog.json'),catalog=read(catalogPath);
catalog.entries=[...newEntries,...catalog.entries.filter(e=>!newEntries.some(n=>n.id===e.id))];write(catalogPath,catalog);
const complete=new Zip();
for(const f of walk('out/files'))complete.addFile('files/'+path.relative('out/files',f).replaceAll('\\','/'),fs.readFileSync(f));
for(const e of newEntries.filter(e=>e.artifactType==='bundle'))complete.addLocalFile(path.join(repo,'static/sbom',e.downloadUrl),'bundles');
for(const name of ['README.md','vex-assessments.json','scan-summary.json','provenance.json','assessment-evidence.zip'])complete.addLocalFile(path.join(release,name));
complete.addFile('osv-results.json',Buffer.from(JSON.stringify(portableScan,null,2)+'\n'));
complete.writeZip(path.join(release,'reveal-2.3.2-sbom-vex.zip'));
write(path.join(release,'checksums.json'),{algorithm:'SHA-256',files:walk(release).filter(f=>!f.endsWith('checksums.json')).map(f=>({file:path.basename(f),sha256:hash(f)}))});
console.log(JSON.stringify({release,documents:coverage.documents.length,bundles:3,completeBundle:path.join(release,'reveal-2.3.2-sbom-vex.zip')},null,2));
