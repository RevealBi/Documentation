import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const read = p => JSON.parse(fs.readFileSync(p, 'utf8'));
const write = (p, value) => { fs.mkdirSync(path.dirname(p), {recursive:true}); fs.writeFileSync(p,JSON.stringify(value,null,2)+'\n'); };
for (const [name, dir] of [['reveal-sdk','client'],['reveal-sdk-node','node']]) {
  const meta = read(`evidence/${name}-metadata.json`);
  const bytes = fs.readFileSync(`artifacts/${name}-2.3.2.tgz`);
  if (`sha512-${crypto.createHash('sha512').update(bytes).digest('base64')}` !== meta.dist.integrity) throw new Error(`Integrity mismatch: ${name}`);
  write(`projects/${dir}/package.json`, {name,version:'2.3.2',description:meta.description,author:meta.author,license:meta.license,dependencies:meta.dependencies??{}});
}
const search = read('evidence/nuget-search.json');
const packages = search.data.filter(p => p.id.startsWith('Reveal.Sdk.') && p.versions.some(v => v.version === '2.3.2')).map(p=>p.id).sort();
if (!packages.includes('Reveal.Sdk.AspNetCore') || !packages.includes('Reveal.Sdk.Data')) throw new Error('Missing base packages');
write('evidence/nuget-packages.json', packages);
fs.mkdirSync('projects/dotnet',{recursive:true});
fs.writeFileSync('projects/dotnet/NuGet.Config', '<configuration><packageSources><clear/><add key="nuget.org" value="https://api.nuget.org/v3/index.json"/></packageSources></configuration>');
for (const name of [...packages,'reveal-server-dotnet-all-connectors']) {
  const deps = name.startsWith('reveal-server') ? packages.filter(p=>p.startsWith('Reveal.Sdk.Data')||p==='Reveal.Sdk.AspNetCore') : [name];
  const folder = `projects/dotnet/${name}`;
  fs.mkdirSync(folder,{recursive:true});
  fs.writeFileSync(`${folder}/${name}.csproj`, `<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><PackageId>SBOM.Snapshot.${name}</PackageId><TargetFramework>net8.0</TargetFramework><RestorePackagesWithLockFile>true</RestorePackagesWithLockFile><NuGetAudit>false</NuGetAudit></PropertyGroup><ItemGroup>${deps.map(p=>`<PackageReference Include="${p}" Version="[2.3.2]"/>`).join('')}</ItemGroup></Project>`);
}
for (const platform of ['windows-x86_64','linux-x86_64']) {
  const folder=`projects/java-${platform}`;
  fs.mkdirSync(folder,{recursive:true});
  fs.writeFileSync(`${folder}/pom.xml`, `<project xmlns="http://maven.apache.org/POM/4.0.0"><modelVersion>4.0.0</modelVersion><groupId>io.revealbi.sbom</groupId><artifactId>reveal-sdk-java-${platform}</artifactId><version>2.3.2</version><repositories><repository><id>reveal</id><url>https://maven.revealbi.io/repository/public</url></repository></repositories><dependencies><dependency><groupId>io.revealbi</groupId><artifactId>reveal-sdk-servlet</artifactId><version>2.3.2</version></dependency><dependency><groupId>io.revealbi</groupId><artifactId>reveal-sdk-engine-${platform}</artifactId><version>2.3.2</version></dependency></dependencies></project>`);
}
console.log(JSON.stringify({packages},null,2));
