import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const Ajv=require('./tools/node_modules/ajv');
const addFormats=require('./tools/node_modules/ajv-formats');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const ajv=new Ajv({strict:false,allErrors:true});addFormats(ajv);
require('./tools/node_modules/ajv-formats-draft2019')(ajv);
ajv.addSchema(read('tools/cryptography-defs.schema.json'),'http://cyclonedx.org/schema/cryptography-defs.schema.json');
ajv.addSchema(read('tools/spdx.schema.json'),'http://cyclonedx.org/schema/spdx.schema.json');
ajv.addSchema(read('tools/jsf-0.82.schema.json'),'http://cyclonedx.org/schema/jsf-0.82.schema.json');
const validate=ajv.compile(read('tools/bom-1.7.schema.json'));
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):e.name.endsWith('.cdx.json')?[path.join(dir,e.name)]:[]);}
const docs=files(process.argv[2]??'out/files');
for(const f of docs){
  const d=read(f);
  if(!validate(d)) throw new Error(`${f}: ${JSON.stringify(validate.errors)}`);
  const refs=new Set([d.metadata.component,...d.components].map(c=>c['bom-ref']));
  if(refs.size!==d.components.length+1) throw new Error(`Duplicate refs ${f}`);
  for(const dep of d.dependencies??[])for(const ref of [dep.ref,...(dep.dependsOn??[])])if(!refs.has(ref))throw new Error(`Unknown dependency ${f}: ${ref}`);
  for(const v of d.vulnerabilities??[])for(const affected of v.affects??[])if(!refs.has(affected.ref))throw new Error(`Unknown VEX component ${f}: ${affected.ref}`);
}
console.log(`Validated ${docs.length} CycloneDX 1.7 documents, dependency graphs and VEX references.`);
